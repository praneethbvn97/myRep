import React from 'react';

import './App.css';

import Weather from './app-component/weathercomponent';
import Form from './app-component/formcomponent';
import 'bootstrap/dist/css/bootstrap.min.css';
//import 'weather-icons/css/weather-icons.css';


const API_Key = "1966d8ba3a69dfafc7adeafe15c4c770";

//apicall api.openweathermap.org/data/2.5/weather?q=London,uk


class App extends React.Component {

  constructor(){
    super();
    this.state={
      city : undefined,
      country : undefined,
      main : undefined,
      celcius : undefined,
      temp_max : undefined,
      temp_min : undefined,
      description : "",
      error : false
    };
    

  }

  CalCelcius(temp){
    let cell = Math.floor(temp-273.15);
    return cell;
  }



  getWeather = async (e) => {
    e.preventDefault();
    const city=e.target.elements.city.value;
    const country=e.target.elements.country.value;

    if (city && country) {
      const api_call = await fetch(`http://api.openweathermap.org/data/2.5/weather?q=${city},${country}uk&appid=${API_Key}`
  );

  const response = await api_call.json();

  console.log(response);

  this.setState({
    city:`${response.name}, ${response.sys.country}`,
    
    celcius: this.CalCelcius(response.main.temp),
    temp_max: this.CalCelcius(response.main.temp_max),
    temp_min: this.CalCelcius(response.main.temp_min),
    description: response.weather[0].description,
    error: false

  });
      
    } else {
      this.setState({error:true});
      
    }


  };
  render() { 
    return ( 
      <div className="App">
      <Form loadweather={this.getWeather} error={this.state.error}/>
     <Weather city={this.state.city} 
     country={this.state.country} 
     temp_celcius={this.state.celcius} 
     temp_max={this.state.temp_max} 
     temp_min={this.state.temp_min} 
     description={this.state.description} />
    </div>

     );
  }
}
 

export default App;
